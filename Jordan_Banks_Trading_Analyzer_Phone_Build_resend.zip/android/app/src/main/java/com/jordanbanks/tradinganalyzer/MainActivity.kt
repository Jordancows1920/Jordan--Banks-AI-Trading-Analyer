package com.jordanbanks.tradinganalyzer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF101827)
private val Panel = Color(0xFF1B2738)
private val Accent = Color(0xFF5DD6A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Navy, surface = Panel)) { AnalyzerScreen() } }
    }
}

@Composable
fun AnalyzerScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var symbol by remember { mutableStateOf("EUR/USD") }
    var timeframe by remember { mutableStateOf("1H") }
    var notes by remember { mutableStateOf("") }
    var apiUrl by remember { mutableStateOf("http://10.0.2.2:8000") }
    var result by remember { mutableStateOf<JSONObject?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { imageUri = it; result = null; error = "" }

    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoGraph, null, tint = Accent, modifier = Modifier.size(34.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("JORDAN BANKS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("AI TRADING CHART ANALYZER", color = Accent, fontSize = 11.sp, letterSpacing = 1.4.sp)
            }
        }
        Text("Upload a chart screenshot. Get a cautious AI read of the visible setup.", color = Color.LightGray)
        OutlinedTextField(value = apiUrl, onValueChange = { apiUrl = it }, label = { Text("Analysis server URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = symbol, onValueChange = { symbol = it }, label = { Text("Symbol") }, modifier = Modifier.weight(1f), singleLine = true)
            OutlinedTextField(value = timeframe, onValueChange = { timeframe = it }, label = { Text("Timeframe") }, modifier = Modifier.weight(1f), singleLine = true)
        }
        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Optional notes (e.g. session, direction)") }, modifier = Modifier.fillMaxWidth())
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (imageUri != null) {
                    val bitmap = remember(imageUri) { context.contentResolver.openInputStream(imageUri!!)?.use { BitmapFactory.decodeStream(it) } }
                    if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 260.dp), contentScale = ContentScale.Fit)
                } else {
                    Icon(Icons.Default.AddPhotoAlternate, null, tint = Accent, modifier = Modifier.size(48.dp))
                    Text("No chart screenshot selected", color = Color.LightGray)
                }
                OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Choose screenshot") }
            }
        }
        Button(onClick = {
            val uri = imageUri
            if (uri == null) { error = "Choose a chart screenshot first."; return@Button }
            if (apiUrl.isBlank()) { error = "Enter your analysis server URL."; return@Button }
            loading = true; error = ""; result = null
            scope.launch {
                try { result = withContext(Dispatchers.IO) { uploadChart(context, apiUrl.trim(), uri, symbol, timeframe, notes) } }
                catch (e: Exception) { error = e.message ?: "Could not analyze chart." }
                finally { loading = false }
            }
        }, enabled = !loading, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Navy)) {
            if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = Navy, strokeWidth = 2.dp)
            else { Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("ANALYZE CHART", fontWeight = FontWeight.Bold) }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80))
        result?.let { AnalysisResult(it) }
        Text("Educational use only. AI estimates can be wrong. Never risk money based only on this analysis.", color = Color.Gray, fontSize = 11.sp)
    }
}

private fun uploadChart(context: android.content.Context, base: String, uri: Uri, symbol: String, timeframe: String, notes: String): JSONObject {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read selected image.")
    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
    val boundary = "JordanBanksBoundary${System.currentTimeMillis()}"
    val body = MultipartBody.Builder(boundary).setType(MultipartBody.FORM)
        .addFormDataPart("symbol", symbol)
        .addFormDataPart("timeframe", timeframe)
        .addFormDataPart("notes", notes)
        .addFormDataPart("image", "chart.${if (mime.contains("png")) "png" else "jpg"}", bytes.toRequestBody(mime.toMediaType()))
        .build()
    val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
    val request = Request.Builder().url(base.trimEnd('/') + "/analyze").post(body).build()
    client.newCall(request).execute().use { response ->
        val text = response.body?.string() ?: ""
        if (!response.isSuccessful) throw IllegalStateException(try { JSONObject(text).optString("detail", "Server error ${response.code}") } catch (_: Exception) { "Server error ${response.code}: $text" })
        return JSONObject(text)
    }
}

@Composable
private fun AnalysisResult(data: JSONObject) {
    val probs = data.optJSONObject("probabilities") ?: JSONObject()
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("ANALYSIS RESULT", color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("${data.optString("symbol")} • ${data.optString("timeframe")}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(data.optString("direction", "Unclear").uppercase(), color = Accent, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text("Bullish ${probs.optInt("bullish")}%  |  Bearish ${probs.optInt("bearish")}%  |  Neutral ${probs.optInt("neutral")}% ", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Confidence: ${data.optString("confidence")} • Visual AI estimate, not calibrated odds", color = Color.LightGray, fontSize = 12.sp)
            ResultSection("Trend", data.optString("trend_summary"))
            ResultSection("Market structure", data.optString("market_structure"))
            ResultSection("Trendlines", data.optString("trendlines"))
            ResultSection("News context", data.optString("news_context"))
            ResultSection("What could invalidate this view", data.optString("what_would_invalidate"))
            JsonArraySection("Candlestick patterns", data.optJSONArray("candlestick_patterns"), "name", "evidence")
            JsonArraySection("Indicators", data.optJSONArray("indicators"), "name", "observation")
            JsonArraySection("Support / resistance", data.optJSONArray("support_resistance"), "kind", "description")
            JsonArraySection("Bullish factors", data.optJSONArray("bullish_factors"))
            JsonArraySection("Bearish factors", data.optJSONArray("bearish_factors"))
            Text(data.optString("probability_note"), color = Color.Gray, fontSize = 11.sp)
            Text(data.optString("disclaimer"), color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ResultSection(title: String, value: String) {
    if (value.isNotBlank() && value != "null") Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = Accent, fontWeight = FontWeight.Bold)
        Text(value, color = Color.White)
    }
}

@Composable
private fun JsonArraySection(title: String, array: org.json.JSONArray?, key1: String = "", key2: String = "") {
    if (array != null && array.length() > 0) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Accent, fontWeight = FontWeight.Bold)
            for (i in 0 until array.length()) {
                val item = array.opt(i)
                val line = if (item is JSONObject) listOf(item.optString(key1), item.optString(key2)).filter { it.isNotBlank() && it != "null" }.joinToString(" — ") else item.toString()
                Text("• $line", color = Color.White)
            }
        }
    }
}
